#include <stdio.h>

void second(void){
printf("wwf\n");
}