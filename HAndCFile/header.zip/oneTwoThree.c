#include <stdio.h>
#include "wwf.h"
void first(int x){
    second();
    printf("%d",x+1);
    printf("2");
    printf("3");
}